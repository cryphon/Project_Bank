﻿namespace assignment3
{
    public interface IObserver
    {
        void update(Song song);
        void DisplayData();
    }
}
