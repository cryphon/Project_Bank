﻿namespace assignment3
{
    public interface IObserver
    {
        void Update(Song song);
        void DisplayData();
    }
}
